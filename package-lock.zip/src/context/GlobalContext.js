import { useNavigation } from "@react-navigation/native";
import { createContext } from "react";
export const ContextGlobal = createContext();
export function GlobalContext({ children }) {
  const navigation = useNavigation();
  const handleRedirect = (route) => {
    navigation.navigate(route);
  };
  const handleGoBack = () => {
    navigation.goBack();
  };

  return (
    <ContextGlobal.Provider value={{ handleRedirect, handleGoBack, navigation }}>
      {children}
    </ContextGlobal.Provider>
  );
}
