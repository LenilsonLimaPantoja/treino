import { StyleSheet, View } from "react-native";
import { HeaderSimples } from "../components/HeaderSimples";
export default function Sobre() {
  return (
    <>
      <HeaderSimples route="Treino" />
      <View style={styles.container}>
      </View>
    </>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#6464f8",
    alignItems: "center",
    justifyContent: "center",
  },
});
