import { useContext } from "react";
import { Button, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { HeaderHome } from "../components/HeaderHome";
import { ContextGlobal } from "../context/GlobalContext";

export default function Home() {
  const { handleRedirect } = useContext(ContextGlobal);
  return (
    <>
      <HeaderHome />
      <View style={styles.container}>
        <TouchableOpacity
          style={[styles.card, { elevation: 10 }]}
          activeOpacity={0.5}
          onPress={() => handleRedirect("Sobre")}
        >
          <Text style={styles.textCard}>Treino de hoje</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.card, { elevation: 10 }]}
          activeOpacity={0.5}
          onPress={() => handleRedirect("Sobre")}
        >
          <Text style={styles.textCard}>Visualizar Todos os Treinos</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.card, { elevation: 10 }]}
          activeOpacity={0.5}
          onPress={() => handleRedirect("Sobre")}
        >
          <Text style={styles.textCard}>Visualizar Todos os Equipamentos</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.card, { elevation: 10 }]}
          activeOpacity={0.5}
          onPress={() => handleRedirect("Sobre")}
        >
          <Text style={styles.textCard}>Adicionar Novo Treino</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.card, { elevation: 10 }]}
          activeOpacity={0.5}
          onPress={() => handleRedirect("Sobre")}
        >
          <Text style={styles.textCard}>Adicionar Novo Equipamento</Text>
        </TouchableOpacity>
      </View>
    </>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#6464f8",
    alignItems: "center",
    justifyContent: "center",
    padding: 10,
  },
  card: {
    backgroundColor: "#fff",
    height: 70,
    width: "100%",
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 5,
    marginTop: 10,
  },
  textCard: {
    color: "#f66",
    textTransform: "uppercase",
    fontWeight: "bold",
  },
});
