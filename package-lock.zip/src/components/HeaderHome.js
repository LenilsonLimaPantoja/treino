import React from "react";
import { StyleSheet, Text, View } from "react-native";
export const HeaderHome = () => {
  return (
    <View style={[styles.container, { elevation: 10 }]}>
      <Text style={styles.text}>Home</Text>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    height: 70,
    backgroundColor: "#f66",
    alignItems: "center",
    justifyContent: "center",
  },
  text: {
    color: "white",
    textTransform: "uppercase",
    fontSize: 20,
    fontWeight: "bold",
  },
});
