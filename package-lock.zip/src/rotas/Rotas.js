import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Home from "../page/Home";
import Sobre from "../page/Sobre";

const Stack = createNativeStackNavigator();

export default function Rotas() {
  return (
    <Stack.Navigator screenOptions={{headerShown: false}}>
      <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="Sobre" component={Sobre} />
    </Stack.Navigator>
  );
}
